<div class="container mainContainer">

	<div class="row">
	
	  <div class="col-8">
	  	
	  	<h2>Your Books</h2>

	  	<?php displayBooks('yourBooks'); ?>

	  </div>
	
	  <div class="col-4">
	  	
	  	<?php displaySearch(); ?>

	  	<hr>

	  	<?php displayPostBook(); ?>

	  </div>
	
	</div>

</div>

